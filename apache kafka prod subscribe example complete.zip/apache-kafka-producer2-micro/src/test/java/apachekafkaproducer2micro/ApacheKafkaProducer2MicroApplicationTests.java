package apachekafkaproducer2micro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApacheKafkaProducer2MicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
