package apachekafkaproducer2micro.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.ExceptionHandler;

import apachekafkaproducer2micro.Domain.DoctorDomain;

@Repository
public interface DoctorDomainReposiroty extends CrudRepository<DoctorDomain, Long>{

}
