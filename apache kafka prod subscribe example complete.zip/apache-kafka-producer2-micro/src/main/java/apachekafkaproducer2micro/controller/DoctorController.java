package apachekafkaproducer2micro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import apachekafkaproducer2micro.Appointment;
import apachekafkaproducer2micro.Domain.DoctorDomain;
import apachekafkaproducer2micro.repository.DoctorDomainReposiroty;

@RestController
@RequestMapping("/doctor")
public class DoctorController {

	@Autowired
	private DoctorDomainReposiroty doctorDomainReposiroty;
	@Autowired
	private KafkaTemplate<String, Appointment> kafkaTemplate;

	@Value("${appointment.book.topic}")
	private String apptTopic;

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveDoctor(@RequestBody DoctorDomain doc) {
		if (null != doc) {
			doctorDomainReposiroty.save(doc);
			kafkaTemplate.send(apptTopic, convertDoctor(doc));
			return "Doctor data saved successfully";
		} else {
			return "failed to save doctor.. Doctor is no more....";
		}

	}

	public Appointment convertDoctor(DoctorDomain doc) {
		Appointment appt = new Appointment();
		appt.setDrId(doc.getId());
		appt.setDocName(doc.getDoctorName());
		appt.setDocStatus(doc.getDoctorStatus());
		return appt;
	}
}
