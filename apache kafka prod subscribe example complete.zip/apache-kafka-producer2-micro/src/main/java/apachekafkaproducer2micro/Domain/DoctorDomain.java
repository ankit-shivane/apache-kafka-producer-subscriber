package apachekafkaproducer2micro.Domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "doctor_data", schema = "doctor_schema")
public class DoctorDomain {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Column(name = "doctor_name")
	private String DoctorName;
	@Column(name = "doctor_status")
	private String DoctorStatus;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDoctorName() {
		return DoctorName;
	}
	public void setDoctorName(String doctorName) {
		DoctorName = doctorName;
	}
	public String getDoctorStatus() {
		return DoctorStatus;
	}
	public void setDoctorStatus(String doctorStatus) {
		DoctorStatus = doctorStatus;
	}

	
}
