package com.akafka.consumer.ServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.akafka.consumer.Repository.ReportingMasterRepository;
import com.akafka.consumer.domain.ReportMaster;
import com.akafka.consumer.model.Appointment;
import com.akafka.consumer.model.User;

@Service
public class KafkaConsumer {
	/*@Value("${appointment.book.topic}")
	private String apptTopic;*/
	@Autowired
	private ReportingMasterRepository reportingMasterRepository;
    @KafkaListener(topics = "Kafka_Example", groupId = "group_id")
    public void consume(String message) {
        System.out.println("Consumed message: " + message);
    }


    @KafkaListener(topics = "Kafka_Example_json", groupId = "group_json",
            containerFactory = "userKafkaListenerFactory")
    public void consumeJson(User user) {
        System.out.println("Consumed JSON Message: " + user);
    }
    @KafkaListener(topics = "${appointment.book.topic}", groupId = "g_json",
            containerFactory = "apptKafkaListenerFactory")
    public void consumeJson(Appointment appt) {
    	if(null != appt) {
    		System.out.println("Consumed JSON Message: " + appt);
        	reportingMasterRepository.save(convertReportMaster(appt));
	
    	}else {
    		System.out.println("Failed to save null data");	
    	}
		
    	
        
    }
    public ReportMaster convertReportMaster(Appointment appt) {
    	ReportMaster reportMaster=new ReportMaster();
    	reportMaster.setApptcode(appt.getApptcode());
    	reportMaster.setDocName(appt.getDocName());
    	reportMaster.setDocStatus(appt.getDocStatus());
    	reportMaster.setDrId(appt.getDrId());
    	reportMaster.setId(appt.getId());
    	reportMaster.setPatientName(appt.getPatientName());
    	reportMaster.setStatus(appt.getStatus());
    	return reportMaster;
    }
}