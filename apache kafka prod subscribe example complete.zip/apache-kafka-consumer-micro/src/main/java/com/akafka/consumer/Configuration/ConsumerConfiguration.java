/*package com.akafka.consumer.Configuration;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import com.akafka.consumer.model.Appointment;


@EnableKafka
@Configuration
public class ConsumerConfiguration {

	@Bean
	public ConsumerFactory<String, Appointment> appointmentconsumerFactory(){
		Map<String,Object> configs=new HashMap<>();
		configs.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
		configs.put(ConsumerConfig.GROUP_ID_CONFIG, "myconsumerGroup");
		configs.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		configs.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
		return new DefaultKafkaConsumerFactory<>(configs,new StringDeserializer(), new JsonDeserializer<>(Appointment.class));
	}
	
	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, Appointment> kafkaListnerContainer(){
		ConcurrentKafkaListenerContainerFactory<String, Appointment> on=new ConcurrentKafkaListenerContainerFactory<>();
		on.setConsumerFactory(appointmentconsumerFactory());
		return on;
	}


	@Bean
	@ConditionalOnMissingBean(name = "kafkaConsumerFactory")
//	@ConditionalOnMissingBean(ConsumerFactory.class) 
	public ConsumerFactory<String, String> consumerFactory(){
		Map<String,Object> configs=new HashMap<>();
		configs.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
		configs.put(ConsumerConfig.GROUP_ID_CONFIG, "myconsumerGroup");
		configs.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		configs.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		return new DefaultKafkaConsumerFactory<>(configs);
	}
	
	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, String> kafkaConsumerFactory(){
		ConcurrentKafkaListenerContainerFactory<String, String> on=new ConcurrentKafkaListenerContainerFactory<>();
		on.setConsumerFactory(consumerFactory());
		return on;
	}


	@Bean
	public ConsumerFactory<String, Appointment> greetingConsumerFactory() {
		Map<String,Object> configs=new HashMap<>();
		configs.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
		configs.put(ConsumerConfig.GROUP_ID_CONFIG, "myconsumerGroup");
		configs.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		configs.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
		return new DefaultKafkaConsumerFactory<>(configs,new StringDeserializer(),new JsonDeserializer<>(Appointment.class));
	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, Appointment> greetingKafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, Appointment> factory =new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(greetingConsumerFactory());
		return factory;
	}
	
	
	   @Bean
	    public ConsumerFactory<String, String> consumerFactory1() {
	        Map<String, Object> config = new HashMap<>();

	        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
	        config.put(ConsumerConfig.GROUP_ID_CONFIG, "group_id");
	        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
	        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);

	        return new DefaultKafkaConsumerFactory<>(config);
	    }


	    @Bean
	    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
	        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory();
	        factory.setConsumerFactory(consumerFactory1());
	        return factory;
	    }
	    
	    public ConsumerFactory<String, Appointment> cosumerFactoryForAppointment(){
	        Map<String, Object> config = new HashMap<>();

	        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
	        config.put(ConsumerConfig.GROUP_ID_CONFIG, "group_appointment");
	        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
	        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
		DefaultKafkaConsumerFactory<String, String> consumerFactory1= new DefaultKafkaConsumerFactory<String, Appointment>(config, new StringDeserializer(),  new JsonDeserializer<>(Appointment.class));
		return consumerFactory1;
	    	return new DefaultKafkaConsumerFactory<String, Appointment>(config, new StringDeserializer(), new JsonDeserializer<>(Appointment.class));
	    }
	    @Bean
	    public ConcurrentKafkaListenerContainerFactory<String, Appointment> kafkaListConForAppointment(){
	    	ConcurrentKafkaListenerContainerFactory<String, Appointment> factory = new ConcurrentKafkaListenerContainerFactory();
	        factory.setConsumerFactory(cosumerFactoryForAppointment());
	        return factory;
	    }

}
*/