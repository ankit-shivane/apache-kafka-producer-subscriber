package com.akafka.consumer.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "reporting_master", schema = "doctor_schema")
public class ReportMaster {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Column(name = "appointment_id")
	private Long apptId;
	@Column(name = "patient_name")
	private String patientName;
	@Column(name = "appointment_code")
	private String apptcode;
	@Column(name = "appointment_status")
	private String status;
	@Column(name = "doctor_id")
	private Long drId;
	@Column(name = "doctor_name")
	private String DocName;
	@Column(name = "doctor_status")
	private String DocStatus;

	/*
	 * public Appointment(String patientName, String apptcode, String status) {
	 * this.patientName = patientName; this.apptcode = apptcode; this.status =
	 * status; }
	 */

	public Long getId() {
		return apptId;
	}

	public void setId(Long id) {
		this.apptId = id;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getApptcode() {
		return apptcode;
	}

	public void setApptcode(String apptcode) {
		this.apptcode = apptcode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getDrId() {
		return drId;
	}

	public void setDrId(Long drId) {
		this.drId = drId;
	}

	public String getDocName() {
		return DocName;
	}

	public void setDocName(String docName) {
		DocName = docName;
	}

	public String getDocStatus() {
		return DocStatus;
	}

	public void setDocStatus(String docStatus) {
		DocStatus = docStatus;
	}

	@Override
	public String toString() {
		return "Appointment [apptId=" + apptId + ", patientName=" + patientName + ", apptcode=" + apptcode + ", status="
				+ status + ", drId=" + drId + ", DocName=" + DocName + ", DocStatus=" + DocStatus + "]";
	}

	/*
	 * //@Override public String toString() { final StringBuffer sb = new
	 * StringBuffer("Appoitment{");
	 * sb.append("name='").append(patientName).append('\'');
	 * sb.append(", apptcode='").append(apptcode).append('\''); sb.append('}');
	 * return sb.toString(); return "Appointment{" + "name='" + patientName + '\'' +
	 * ", apptcode='" + apptcode + '\'' + ", status='"+status+'\''+ '}'; }
	 */

}
