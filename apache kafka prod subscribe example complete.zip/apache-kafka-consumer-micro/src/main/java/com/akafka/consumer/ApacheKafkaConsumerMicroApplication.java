package com.akafka.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApacheKafkaConsumerMicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApacheKafkaConsumerMicroApplication.class, args);
	}
/* 
 
 
 http://localhost:8083/publish/appointment
 {
	
	"patientName":"vikrant",
	"apptcode":"10457842054879564589",
	"status":"reschedule"
}

http://localhost:8085/doctor/save

{
	
	"doctor_name":"Sameer",
	"doctor_status":"Available"
}


listen to kafka topic

kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic appt_topics --from-beginning

create topic

kafka-topics.bat --create --bootstrap-server localhost:9092 --replication-factor 1 --partitions 1 --topic appt_topics
 
 */
}
