package com.akafka.consumer.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.akafka.consumer.domain.ReportMaster;

@Repository
public interface ReportingMasterRepository extends CrudRepository<ReportMaster, Long>{

}
