/*package com.akafka.consumer.ServiceImplementation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.akafka.consumer.model.Appointment;

@Service
public class ConsumerServiceImplementation {
	private static final Logger log=LoggerFactory.getLogger(ConsumerServiceImplementation.class);
	@Autowired
	private KafkaTemplate<String, Appointment> kafkaTemplate;
	
//	@Value("${appointment.book.topic}")
//	private static final String AppointmentBookingTopics="appointment.book.topic";
	
	@KafkaListener(topics=AppointmentBookingTopics,groupId="myconsumerGroup",containerFactory="greetingKafkaListenerContainerFactory")
	public void consumer(Appointment appt) {
		log.info("message is = {}",appt);
	}
	
	@KafkaListener(topics="string_data_topic",groupId="group_id")
	public void consumer2(String stf) {
		log.info("message is = {}",stf);
	}
	
	@KafkaListener(topics="appt",groupId="group_appointment",containerFactory = "kafkaListConForAppointment")
	public void consumer1(Appointment stf) {
		log.info("message is = {}",stf);
	}
	
}
*/