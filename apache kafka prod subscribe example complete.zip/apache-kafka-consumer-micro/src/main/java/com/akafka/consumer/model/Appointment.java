package com.akafka.consumer.model;

public class Appointment {
	private Long apptId;
	private String patientName;
	private String apptcode;
	private String status;
	private Long drId;
	private String DocName;
	private String DocStatus;
	
	public Appointment() {

	}
	/*
	 * public Appointment(String patientName, String apptcode, String status) {
	 * this.patientName = patientName; this.apptcode = apptcode; this.status =
	 * status; }
	 */

	public Long getId() {
		return apptId;
	}

	public Appointment(Long apptId, String patientName, String apptcode, String status) {
		super();
		this.apptId = apptId;
		this.patientName = patientName;
		this.apptcode = apptcode;
		this.status = status;
	}

	public void setId(Long id) {
		this.apptId = id;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getApptcode() {
		return apptcode;
	}

	public void setApptcode(String apptcode) {
		this.apptcode = apptcode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getDrId() {
		return drId;
	}

	public void setDrId(Long drId) {
		this.drId = drId;
	}

	public String getDocName() {
		return DocName;
	}

	public void setDocName(String docName) {
		DocName = docName;
	}

	public String getDocStatus() {
		return DocStatus;
	}

	public void setDocStatus(String docStatus) {
		DocStatus = docStatus;
	}

	@Override
	public String toString() {
		return "Appointment [apptId=" + apptId + ", patientName=" + patientName + ", apptcode=" + apptcode + ", status="
				+ status + ", drId=" + drId + ", DocName=" + DocName + ", DocStatus=" + DocStatus + "]";
	}
	
/*
	//@Override
	public String toString() {
        final StringBuffer sb = new StringBuffer("Appoitment{");
        sb.append("name='").append(patientName).append('\'');
        sb.append(", apptcode='").append(apptcode).append('\'');
        sb.append('}');
        return sb.toString();
		return "Appointment{" +
        "name='" + patientName + '\'' +
        ", apptcode='" + apptcode + '\'' +
        ", status='"+status+'\''+
        '}';
    }
	*/
	
}
