package com.akafka.produce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.akafka.produce.AppointmentDom;
import org.springframework.web.bind.annotation.RestController;

import com.akafka.produce.model.Appointment;
import com.akafka.produce.service.Implementation.ProducerServiceImplementation;
import com.akafka.produce.service.Implementation.UserProducerService;

@RestController
public class ProducerController {

	@Autowired
	private ProducerServiceImplementation producerServiceImplementation;

	@Autowired
	private UserProducerService userProducerService;

	@GetMapping("/publish/{name}")
	public String post(@PathVariable("name") final String name) {
		userProducerService.sendUserMsg(name);
		return "Published successfully";
	}

	/*
	 * @RequestMapping(value="/producer1/{msg}",method=RequestMethod.GET) public
	 * String producer1(@PathVariable(value="msg") String message) { return
	 * producerServiceImplementation.produceMsg(message); }
	 */

	@RequestMapping(value = "/publish/{id}/{patientName}/{apptCode}/{apptstatus}", method = RequestMethod.GET)
	public String producer1(@PathVariable("id") Long id, @PathVariable("patientName") String patientName,
			@PathVariable("apptCode") String apptCode, @PathVariable("apptstatus") String apptstatus) {
		return producerServiceImplementation
				.appointmentBookingTopic(new Appointment(id, patientName, apptCode, apptstatus));
	}

	@RequestMapping(value = "/publish/appointment", method = RequestMethod.POST)
	public String saveAppointment(@RequestBody AppointmentDom appt) {
		return producerServiceImplementation.saveAppointmentData(appt);
	}
}
