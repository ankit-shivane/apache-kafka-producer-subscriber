package com.akafka.produce.service.Implementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.akafka.produce.AppointmentDom;
import com.akafka.produce.AppointmentRepository;
import com.akafka.produce.model.Appointment;

@Component
public class ProducerServiceImplementation {

	@Autowired
	private AppointmentRepository appoinmentRepository;

	/*
	 * @Autowired private KafkaTemplate<String, String> kafkaTemplate;
	 */
	@Autowired
	private KafkaTemplate<String, Appointment> kafkTemplateAppt;

	@Value("${normal.string.topic}")
	private String topics1;

	
	@Value("${appointment.book.topic}")
	private String appointmentBookTopic;

	/*
	 * public String produceMsg(String message) { kafkaTemplate.send(topics1,
	 * message); return "message public successfully..."; }
	 */

	public String appointmentBookingTopic(Appointment appointment) {
		kafkTemplateAppt.send("appt_topics", appointment);
		return "appointment booked successfully";
	}

	public String saveAppointmentData(AppointmentDom appt) {

		if (null != appt) {
			appoinmentRepository.save(appt);

			kafkTemplateAppt.send(appointmentBookTopic, convertApptSave(appt));
		} else {
			return "fail to save appointment data";
		}
		return "successfully Saved appointment data..";
	}

	public Appointment convertApptSave(AppointmentDom apptDom) {
		Appointment appt = new Appointment();
		appt.setApptcode(apptDom.getApptcode());
		appt.setPatientName(apptDom.getPatientName());
		appt.setStatus(apptDom.getStatus());
		appt.setId(apptDom.getId());
		return appt;
	}

}
